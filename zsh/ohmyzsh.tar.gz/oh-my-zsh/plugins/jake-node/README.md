# Jake

This plugin provides completion for [Jake](http://jakejs.com/).

To use it add jake-node to the plugins array in your zshrc file.

```bash
plugins=(... jake-node)
```
