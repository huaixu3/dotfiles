---@meta

---@class cc.EventListenerKeyboard :cc.EventListener
local EventListenerKeyboard={ }
cc.EventListenerKeyboard=EventListenerKeyboard




---* 
---@return boolean
function EventListenerKeyboard:init () end
---* / Overrides
---@return self
function EventListenerKeyboard:clone () end
---* 
---@return boolean
function EventListenerKeyboard:checkAvailable () end
---* 
---@return self
function EventListenerKeyboard:EventListenerKeyboard () end