require 'provider.diagnostic'
return require 'provider.provider'
